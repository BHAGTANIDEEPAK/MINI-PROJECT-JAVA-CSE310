import java.awt.EventQueue;

import java.sql.DriverManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.Color;

public class ViewProfileT extends JFrame {

	private JPanel contentPane;
	private JTextField txtKuchNhi;
	private JTextField txtNewLabel;
	String emai;
	String nam;
	
	public void sEmail(String email) {
		txtKuchNhi.setText(email);
		emai = txtKuchNhi.getText();
		
		
		
	   }
	public void sName(String name) {
		txtNewLabel.setText(name);
		nam = txtKuchNhi.getText();
	   }
      


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewProfileT frame = new ViewProfileT();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewProfileT() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 918, 542);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Welcome to Classroom Management System");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(137, 10, 656, 72);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setBounds(185, 192, 104, 44);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Email-Id");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_2.setBounds(185, 284, 113, 44);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("If You Want to Update Any Information Kindly Contact to 7737292736 OR Visit Block No 34-201");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(10, 402, 894, 81);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Your Profile");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_4.setBounds(367, 92, 168, 44);
		contentPane.add(lblNewLabel_4);
		
		txtKuchNhi = new JTextField(nam);
		txtKuchNhi.setBackground(new Color(248, 248, 255));
		txtKuchNhi.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtKuchNhi.setText(nam);
		txtKuchNhi.setEditable(false);
		txtKuchNhi.setBounds(436, 191, 227, 52);
		contentPane.add(txtKuchNhi);
		txtKuchNhi.setColumns(10);
		
		txtNewLabel = new JTextField(emai);
		txtNewLabel.setBackground(new Color(248, 248, 255));
		txtNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtNewLabel.setEditable(false);
		txtNewLabel.setBounds(436, 283, 326, 52);
		contentPane.add(txtNewLabel);
		txtNewLabel.setColumns(10);
		
		
		
		
		
		

		
	}
}
