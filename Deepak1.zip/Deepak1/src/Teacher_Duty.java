import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;

public class Teacher_Duty extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teacher_Duty frame = new Teacher_Duty();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teacher_Duty() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 789, 538);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Room No.");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(137, 96, 117, 29);
		contentPane.add(lblNewLabel);
		
		JLabel lblClassTiming = new JLabel("Timing");
		lblClassTiming.setHorizontalAlignment(SwingConstants.CENTER);
		lblClassTiming.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblClassTiming.setBounds(346, 96, 117, 29);
		contentPane.add(lblClassTiming);
		
		JLabel lblYourDetails = new JLabel("Your Exam Duty");
		lblYourDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblYourDetails.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblYourDetails.setBounds(295, 44, 168, 29);
		contentPane.add(lblYourDetails);
		
		JLabel lblNewLabel_1 = new JLabel("34-406");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(137, 155, 117, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("34-408");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(137, 209, 117, 29);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("34-512");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(137, 264, 117, 29);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("34-210");
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3.setBounds(137, 317, 117, 29);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("38-809");
		lblNewLabel_1_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3_1.setBounds(137, 372, 117, 29);
		contentPane.add(lblNewLabel_1_3_1);
		
		JLabel lblNewLabel_1_3_2 = new JLabel("37-506");
		lblNewLabel_1_3_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3_2.setBounds(137, 422, 117, 29);
		contentPane.add(lblNewLabel_1_3_2);
		
		JLabel lblSection = new JLabel("Date of Exam");
		lblSection.setHorizontalAlignment(SwingConstants.CENTER);
		lblSection.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSection.setBounds(525, 96, 125, 29);
		contentPane.add(lblSection);
		
		JLabel lblNewLabel_1_4 = new JLabel("10:00AM-12:00PM");
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4.setBounds(322, 155, 159, 29);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_15 = new JLabel("12-05-2023");
		lblNewLabel_1_15.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15.setBounds(525, 155, 117, 29);
		contentPane.add(lblNewLabel_1_15);
		
		JLabel lblNewLabel_1_4_1 = new JLabel("09:00AM-12:00PM");
		lblNewLabel_1_4_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4_1.setBounds(322, 209, 159, 29);
		contentPane.add(lblNewLabel_1_4_1);
		
		JLabel lblNewLabel_1_4_2 = new JLabel("09:00AM-12:00PM");
		lblNewLabel_1_4_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4_2.setBounds(322, 264, 159, 29);
		contentPane.add(lblNewLabel_1_4_2);
		
		JLabel lblNewLabel_1_4_3 = new JLabel("01:00PM-04:00PM");
		lblNewLabel_1_4_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4_3.setBounds(322, 317, 159, 29);
		contentPane.add(lblNewLabel_1_4_3);
		
		JLabel lblNewLabel_1_4_4 = new JLabel("04:00PM-07:00PM");
		lblNewLabel_1_4_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4_4.setBounds(322, 372, 159, 29);
		contentPane.add(lblNewLabel_1_4_4);
		
		JLabel lblNewLabel_1_4_5 = new JLabel("10:00AM-12:00PM");
		lblNewLabel_1_4_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4_5.setBounds(322, 422, 159, 29);
		contentPane.add(lblNewLabel_1_4_5);
		
		JLabel lblNewLabel_1_15_1 = new JLabel("15-05-2023");
		lblNewLabel_1_15_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15_1.setBounds(525, 209, 117, 29);
		contentPane.add(lblNewLabel_1_15_1);
		
		JLabel lblNewLabel_1_15_2 = new JLabel("17-05-2023");
		lblNewLabel_1_15_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15_2.setBounds(525, 264, 117, 29);
		contentPane.add(lblNewLabel_1_15_2);
		
		JLabel lblNewLabel_1_15_3 = new JLabel("21-05-2023");
		lblNewLabel_1_15_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15_3.setBounds(525, 317, 117, 29);
		contentPane.add(lblNewLabel_1_15_3);
		
		JLabel lblNewLabel_1_15_4 = new JLabel("25-05-2023");
		lblNewLabel_1_15_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15_4.setBounds(525, 372, 117, 29);
		contentPane.add(lblNewLabel_1_15_4);
		
		JLabel lblNewLabel_1_15_5 = new JLabel("30-05-2023");
		lblNewLabel_1_15_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_15_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_15_5.setBounds(525, 422, 117, 29);
		contentPane.add(lblNewLabel_1_15_5);
	}
}