

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Teacher_Details extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teacher_Details frame = new Teacher_Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teacher_Details() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1332, 549);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 250, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setEnabled(false);
		scrollPane.setBounds(0, 154, 1308, 286);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.setForeground(new Color(0, 0, 0));
		
		table.setRowHeight(40);
		table.setFont(new Font("Tahoma", Font.PLAIN, 20));
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"CSE 211", "Computer Organisation and Design", "Jai Sukh Pal Singh", "34-210"},
				{"CSE 310", "Java Programming", "Ravi Kant Sahu", "34-213"},
				{"CSE 316", "Operating Systems", "Arshiya", "34-203"},
				{"CSE 325", "Operating System Laborartory", "Arshiya", "34-203"},
				{"CSE 408", "Desing And Analysis Of Algorithmns", "Gurasis Singh", "34-202"},
				{"INT 404", "Artificial Intelligence", "Ankita Wadhabhan", "33-203"},
				{"MTH 302", "Probability And Statistics", "Deepti", "38-301"},
				{"PEA 305", "Analytical Skills - I", "Prakash Kesarawani", "38-509"},
			},
			new String[] {
				"Course Code", "Course Name", "Faculty Name", "Room/Block No."
			}
		));
		
		
		
		JTableHeader header = table.getTableHeader();
		DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
		renderer.setPreferredSize(new Dimension(100, 50)); 
		header.setDefaultRenderer(renderer);
		
		table.getColumnModel().getColumn(0).setPreferredWidth(20);
		table.getColumnModel().getColumn(1).setPreferredWidth(157);
		table.getColumnModel().getColumn(1).setMinWidth(34);
		table.getColumnModel().getColumn(2).setPreferredWidth(90);
		table.getColumnModel().getColumn(3).setPreferredWidth(15);
		table.getColumnModel().getColumn(3).setMinWidth(10);
		
		lblNewLabel = new JLabel("Teacher Details");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 27));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(444, 23, 452, 45);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Section K21RN");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(614, 90, 137, 25);
		contentPane.add(lblNewLabel_1);
	}

}