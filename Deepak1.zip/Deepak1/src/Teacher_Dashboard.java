import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Teacher_Dashboard extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel_3;
	String email;
	String name;
	ViewProfileT obj = new ViewProfileT();
	
	 public void setName(String name) {
	      
	      obj.sEmail(name);
	   }
	 public void setEmail(String email) {
	      lblNewLabel_3.setText(email);
	      obj.sName(email);
	   }
	 
	 
	 

	 

	   

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Teacher_Dashboard frame = new Teacher_Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Teacher_Dashboard() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1228, 712);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("to Teacher's Dashboard");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(474, 141, 336, 71);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("View Profile");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				obj.setVisible(true);			
			}
		});
		btnNewButton.setBounds(59, 250, 214, 55);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Today's Lecture");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Today_T ob1 = new Today_T();
				ob1.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(987, 248, 199, 58);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Exam Duties");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Teacher_Duty ob1 = new Teacher_Duty();
				ob1.setVisible(true);
			}
		});
		btnNewButton_3.setBackground(new Color(255, 255, 255));
		btnNewButton_3.setBounds(59, 516, 214, 55);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Important Details");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Important_Teacher_Details ob1 = new Important_Teacher_Details();
				ob1.setVisible(true);
			}
		});
		btnNewButton_4.setBackground(new Color(255, 255, 255));
		btnNewButton_4.setBounds(501, 516, 231, 55);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_6 = new JButton("ToDolist");
		btnNewButton_6.setBackground(new Color(255, 255, 255));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ToDoT obj = new ToDoT();
				obj.setVisible(true);				
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6.setBounds(987, 515, 198, 56);
		contentPane.add(btnNewButton_6);
		
		lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_3.setBounds(366, 75, 519, 55);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(495, 10, 274, 55);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon(getClass().getResource("/images/image_2.jpg")));
		lblNewLabel_2.setBounds(10, 10, 1204, 655);
		contentPane.add(lblNewLabel_2);
	}
}
