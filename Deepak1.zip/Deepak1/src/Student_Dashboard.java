import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Student_Dashboard extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel_2;
	String name;
	String email;
	
	 public void setName(String name) {
		 lblNewLabel_2.setText(name);
		 this.name = name;
		 
	     
	   }
	 public void setEmail(String email) {
		   this.email = email;
		   
		   
		   
	   }

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student_Dashboard frame = new Student_Dashboard();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Student_Dashboard() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1255, 727);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("to Student's Dashborad");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(10, 130, 1227, 104);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("View Profile");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewProfileS obj = new ViewProfileS();
				obj.sName(name);
				obj.sEmail(email);
				obj.setVisible(true);
			}
		});
		btnNewButton.setBounds(67, 261, 214, 63);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("To-Do List");
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setBounds(629, 515, 214, 63);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ToDoS obj = new ToDoS();
				obj.setVisible(true);
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Today's Lecture");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					Today_S ob1 = new Today_S();
					ob1.setVisible(true);
			}
		});
		btnNewButton_2.setBounds(979, 261, 229, 63);
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Exam Available");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ExamsS ob1 = new ExamsS();
				ob1.setVisible(true);
			}
		});
		btnNewButton_3.setBackground(new Color(255, 255, 255));
		btnNewButton_3.setBounds(67, 515, 214, 63);
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Important Details");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Important_Details ob2 = new Important_Details();
				ob2.setVisible(true);
			}
		});
		btnNewButton_4.setBackground(new Color(255, 255, 255));
		btnNewButton_4.setBounds(334, 515, 214, 63);
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Teacher Details");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Teacher_Details ob1 = new Teacher_Details();
				ob1.setVisible(true);
			}
		});
		btnNewButton_5.setBackground(new Color(255, 255, 255));
		btnNewButton_5.setBounds(918, 515, 247, 63);
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		contentPane.add(btnNewButton_5);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome ");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(246, 10, 722, 76);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		contentPane.add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("new");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 26));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setBounds(495, 73, 220, 76);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(getClass().getResource("/images/image_2.jpg")));
		lblNewLabel_3.setBounds(0, 0, 1237, 680);
		contentPane.add(lblNewLabel_3);
	}

}
