

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

public class Important_Details extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Important_Details frame = new Important_Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Important_Details() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1092, 697);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(240, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea txtrWeveTrainedA = new JTextArea();
		txtrWeveTrainedA.setEditable(false);
		txtrWeveTrainedA.setFont(new Font("Monospaced", Font.BOLD, 25));
		txtrWeveTrainedA.setText("O                       10" + "\n"+  
		                         "A+                      9" + "\n" +
		                         "A                       8" + "\n" +
		                         "B+                      7" + "\n" +
		                         "B                       6" + "\n" +
		                         "C                       5" + "\n" +
		                         "D                       4" + "\n" +
		                         "E(Reappear)             0" + "\n" +
		                         "F(Fail                  0" + "\n" +
		                         "G(Backlog               0" + "\n" +
		                         "I(Result Incomplete)    0" + "\n" );
		
		txtrWeveTrainedA.setBounds(10, 89, 411, 380);
		contentPane.add(txtrWeveTrainedA);
		
		JLabel lblNewLabel = new JLabel("CGP Criteria");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(48, 10, 301, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Grade");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 48, 95, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Points");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setBounds(326, 48, 95, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblSummerTrainingCourse = new JLabel("Summer Training Course");
		lblSummerTrainingCourse.setHorizontalAlignment(SwingConstants.CENTER);
		lblSummerTrainingCourse.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblSummerTrainingCourse.setBounds(664, 10, 301, 28);
		contentPane.add(lblSummerTrainingCourse);
		
		JLabel lblNewLabel_1_2 = new JLabel("Course Name");
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(545, 48, 108, 31);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_2_1 = new JLabel("Offered By..");
		lblNewLabel_1_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2_1.setBounds(743, 48, 118, 31);
		contentPane.add(lblNewLabel_1_2_1);
		
		JTextArea txtrWeveTrainedA_1 = new JTextArea();
		txtrWeveTrainedA_1.setEditable(false);
		txtrWeveTrainedA_1.setText("1.Competitive Programming       Ravi Kant Sahu      2000"
				+ ""+ "\n"+ "Using Data Structures" + "\n\n" + 
				 "2.Android Development           Vin Norman          3999" + "\n\n"+
				  "3.Full Stack Web development    Dr. Angela Yu       499" + "\n\n" + 
				  "4.Python 100 Days(Master)       Mr. Peter           599" + "\n\n" +
				  "5.Java Mastery Course           Maid Rondic         399" + "\n\n" + 
				  "6.Complete C# Game Develop.     Ben Tristem         529");
		txtrWeveTrainedA_1.setFont(new Font("Monospaced", Font.BOLD, 17));
		txtrWeveTrainedA_1.setBounds(448, 89, 620, 380);
		contentPane.add(txtrWeveTrainedA_1);
		
		JLabel lblNewLabel_1_2_1_1 = new JLabel("Fees (in Rs.)");
		lblNewLabel_1_2_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNewLabel_1_2_1_1.setBounds(931, 48, 118, 31);
		contentPane.add(lblNewLabel_1_2_1_1);
		
		JLabel lblNewLabel_2 = new JLabel("Important Messages");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_2.setBounds(427, 509, 170, 28);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("1.   In Case of Any Backlog/Reappear contact to 32-106");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(25, 547, 1002, 28);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("2.   In Case of Any Residential query contact to 32-105");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3_1.setBounds(25, 575, 1002, 28);
		contentPane.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("3.   Query related to placement services 34-202  ");
		lblNewLabel_3_1_1.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblNewLabel_3_1_1.setBounds(25, 602, 1002, 28);
		contentPane.add(lblNewLabel_3_1_1);
	}
}