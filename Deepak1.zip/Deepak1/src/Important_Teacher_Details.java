import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

public class Important_Teacher_Details extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Important_Teacher_Details frame = new Important_Teacher_Details();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Important_Teacher_Details() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1146, 759);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("General Instructions of University");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(392, 34, 347, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("1. To report for duty in time and to record the exact time of arrival and departure in Staff Attendance Register on every working day.");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(72, 77, 910, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("2. To get the due sanction of the leave from the Principal/Management before availing and also to observe the Leave Rules.");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_1.setBounds(72, 112, 910, 31);
		contentPane.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("3. To take the roll call of the students of the class and ensure that the same has been recorded on the UMS Portal.");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_2.setBounds(72, 144, 910, 31);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("4. To intimate properly the detailed, weekly timetable to the students and parents and the change (if any).");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_3.setBounds(72, 177, 910, 31);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("5. To avoid physical /corporal punishment to the student and to talk in English with students and colleagues in the school.");
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1_3_1.setBounds(72, 213, 910, 31);
		contentPane.add(lblNewLabel_1_3_1);
		
		JLabel lblDreeCodePolicy = new JLabel("Dress Code Policy");
		lblDreeCodePolicy.setHorizontalAlignment(SwingConstants.CENTER);
		lblDreeCodePolicy.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblDreeCodePolicy.setBounds(412, 279, 347, 31);
		contentPane.add(lblDreeCodePolicy);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(72, 322, 1020, 329);
		contentPane.add(scrollPane);
		
		JTextArea txtrProfessionalAttire = new JTextArea();
		txtrProfessionalAttire.setEditable(false);
		txtrProfessionalAttire.setFont(new Font("Tahoma", Font.BOLD, 15));
		txtrProfessionalAttire.setText("1. Professional attire: Teachers should dress professionally in a way that is appropriate for their job."
				+ "\n" + " This may include wearing suits, dress pants, blouses, or dresses that are modest and professional." + "\n\n\n" +
				"2. Comfortable footwear: Teachers may spend a lot of time on their feet, so it is important to wear comfortable shoes that are appropriate for the workplace." + "\n\n\n" + 
				"3. Avoiding provocative clothing: Teachers should avoid clothing that is provocative, revealing, or distracting." + "\n\n\n" + 
				 "4.Considering cultural sensitivities: Teachers should be aware of the cultural sensitivities of their students" + "\n" + "and colleagues and dress in a way that shows respect for diverse backgrounds.");
		scrollPane.setViewportView(txtrProfessionalAttire);
	}
}