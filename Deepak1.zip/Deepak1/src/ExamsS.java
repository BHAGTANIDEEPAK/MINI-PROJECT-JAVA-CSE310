import java.awt.EventQueue;
import java.awt.CardLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Component;

public class ExamsS extends JFrame {
	

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblNewLabel_1_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExamsS frame = new ExamsS();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ExamsS() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(200, 50, 838, 663);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		
		JLabel lblNewLabel = new JLabel("<html>" + "<br><br>"+
										"MTH401 " + "<br><br>" +
										"Date:30-4-2023" +"<br><br>"
										+"Room No:34-403" +"<br><br>"
										+"<html/");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBackground(new Color(128, 128, 128));
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBounds(5, 40, 272, 226);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("<html>" + "<br><br>"+
				"CSE316 " + "<br><br>" +
				"Date:1-4-2023" +"<br><br>"
				+"Room No:34-203" +"<br><br>"
				+"<html/");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBounds(278, 40, 280, 226);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("<html>" + "<br><br>"+
				"INT401 " + "<br><br>" +
				"Date:30-5-2023" +"<br><br>"
				+"Room No:34-413" +"<br><br>"
				+"<html/");
		lblNewLabel_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_1.setBounds(557, 40, 267, 226);
		contentPane.add(lblNewLabel_1_1);
		
		lblNewLabel_1_2 = new JLabel("<html>" + "<br><br>"+
				"CSE325 " + "<br><br>" +
				"Date:4-4-2023" +"<br><br>"
				+"Room No:34-803" +"<br><br>"
				+"<html/");
		lblNewLabel_1_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_2.setBounds(0, 400, 280, 226);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("<html>" + "<br><br>"+
				"CSE310 " + "<br><br>" +
				"Date:15-4-2023" +"<br><br>"
				+"Room No:34-403" +"<br><br>"
				+"<html/");
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_1_3.setBounds(278, 400, 280, 226);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("<html>" + "<br><br>"+
				"PEA305 " + "<br><br>" +
				"Date:3-5-2023" +"<br><br>"
				+"Room No:34-403" +"<br><br>"
				+"<html/");
		lblNewLabel_1_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_4.setFont(new Font("Times New Roman", Font.BOLD, 20));
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_4.setOpaque(true);
		lblNewLabel_1_4.setBounds(557, 400, 267, 226);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_2 = new JLabel("Best Of Luck");
		lblNewLabel_2.setOpaque(true);
		lblNewLabel_2.setBackground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 87));
		lblNewLabel_2.setBounds(5, 263, 819, 138);
		contentPane.add(lblNewLabel_2);
		
		
	}
}