import java.awt.EventQueue;
import java.awt.CardLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Component;

public class Today_T extends JFrame {
	

	private JPanel contentPane;
	private JTextField textField;
	private JLabel lblNewLabel_1_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Today_T frame = new Today_T();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Today_T() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(200, 50, 838, 663);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		final JComboBox comboBox = new JComboBox();
		comboBox.setAlignmentX(10.0f);
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 18));
		comboBox.setBounds(5, 5, 819, 37);
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.addItem("Monday");
		comboBox.addItem("Tuesday");
		comboBox.addItem("Wednesday");
		comboBox.addItem("Thrusday");
		comboBox.addItem("Friday");
		comboBox.addItem("Saturday");
		contentPane.add(comboBox);
		
		JLabel lblNewLabel = new JLabel("9-10, K21RN, Room No : 34-304");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBackground(new Color(128, 128, 128));
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBounds(5, 40, 272, 226);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel(" 2-3, K21PP, Room No : 34-704");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBackground(new Color(192, 192, 192));
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBounds(278, 40, 280, 226);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("3-4,K21SN,Room No : 34-904");
		lblNewLabel_1_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setOpaque(true);
		lblNewLabel_1_1.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_1.setBounds(557, 40, 267, 226);
		contentPane.add(lblNewLabel_1_1);
		
		lblNewLabel_1_2 = new JLabel("3-4,K21SN,Room No : 34-904");
		lblNewLabel_1_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_2.setOpaque(true);
		lblNewLabel_1_2.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_2.setBounds(0, 400, 280, 226);
		contentPane.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("4-5,K21LE,Room No : 34-104");
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_3.setOpaque(true);
		lblNewLabel_1_3.setBackground(new Color(192, 192, 192));
		lblNewLabel_1_3.setBounds(278, 400, 280, 226);
		contentPane.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("6:30-8:30,K21RN,myclass");
		lblNewLabel_1_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_1_4.setFont(new Font("Times New Roman", Font.BOLD, 15));
		lblNewLabel_1_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_4.setBackground(new Color(128, 128, 128));
		lblNewLabel_1_4.setOpaque(true);
		lblNewLabel_1_4.setBounds(557, 400, 267, 226);
		contentPane.add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_2 = new JLabel("After Break Classes");
		lblNewLabel_2.setOpaque(true);
		lblNewLabel_2.setBackground(new Color(255, 255, 255));
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 87));
		lblNewLabel_2.setBounds(5, 263, 819, 138);
		contentPane.add(lblNewLabel_2);
		
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	             String item = (String) comboBox.getSelectedItem();
	            
	             
	             
	             	if (item.equals("Monday")) 
	                  {
	             		lblNewLabel.setText("9-10,K21RN,Room No : 34-304");
	             		lblNewLabel_1.setText("10-12,K21ZN,Room No : 34-504");
	             		lblNewLabel_1_1.setText("2-3,K21PP,Room No : 34-704");
	             		lblNewLabel_1_2.setText("3-4,K21SN,Room No : 34-904");
	             		lblNewLabel_1_3.setText("4-5,K21LE,Room No : 34-104");
	             		lblNewLabel_1_4.setText("6:30-8:30,K21RN,myclass");
					  } 
	             	if (item.equals("Tuesday")) 
	                  {
	             		lblNewLabel.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_2.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_3.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_4.setText("Section K21RN,Room No : 34-304");
					  } 
	             	if (item.equals("Wednesday")) 
	                  {
	             		lblNewLabel.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_2.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_3.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_4.setText("Section K21RN,Room No : 34-304");
					  } 
	             	if (item.equals("Thrusday")) 
	                  {
	             		lblNewLabel.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_2.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_3.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_4.setText("Section K21RN,Room No : 34-304");
					  } 
	             	if (item.equals("Friday")) 
	             	{
	             		lblNewLabel.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_2.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_3.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_4.setText("Section K21RN,Room No : 34-304");
					  } 
	             	if (item.equals("Saturday")) 
	                  {
	             		lblNewLabel.setText("Section K21RN,Room No : 34-304");
	             		
	             		lblNewLabel_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_1.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_2.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_3.setText("Section K21RN,Room No : 34-304");
	             		lblNewLabel_1_4.setText("Section K21RN,Room No : 34-304");
					  } 
//	             		
			}
		});
	}
}