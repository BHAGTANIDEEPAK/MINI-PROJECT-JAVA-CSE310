import java.awt.EventQueue;


import java.sql.DriverManager;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.ResultSetMetaData;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class ToDoT extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ToDoT frame = new ToDoT();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ToDoT() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 897, 572);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(248, 248, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("My To-Do List");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel.setBounds(312, 10, 221, 68);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Important Task");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(119, 136, 167, 51);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Other Task");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(119, 241, 146, 51);
		contentPane.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(312, 136, 177, 39);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(536, 124, 308, 369);
		contentPane.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(312, 241, 177, 182);
		contentPane.add(textArea);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Important Task", "Other"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(84);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String template = "jdbc:mysql://localhost/%s?useEncoding=true&characterEncoding=UTF-8&user=%s&password=%s";
				try {
					
					Connection con =DriverManager.getConnection(String.format(template,"studentinfo", "root", ""));
					String imp = textField.getText();
					String other = textArea.getText();
					java.sql.PreparedStatement pst = con.prepareStatement("insert into to_do_t values(?,?)");
					pst.setString(1,imp);
					pst.setString(2, other);
					
					pst.executeUpdate();
					JOptionPane.showMessageDialog(btnNewButton, "task added");
					textField.setText("");
					textArea.setText("");
					
					
					
					
					
					
					
					
					
					
					
					String query = "select * from to_do_t";
					java.sql.PreparedStatement ps = con.prepareStatement(query);
					
					ResultSet rs = ps.executeQuery();
					java.sql.ResultSetMetaData rd = rs.getMetaData();
					int a;
					a = rd.getColumnCount();
					DefaultTableModel df = (DefaultTableModel) table.getModel();
					df.setRowCount(0);
					while(rs.next())
					{
						Vector v2 = new Vector();
						for(int y = 1;y<=a;y++)
						{
							v2.add(rs.getString("Important-Task"));
							v2.add(rs.getString("Other-Task"));
							
						}
						df.addRow(v2);
					}
					
					
					
					
					
					
					
				 
					
					
					
				}
				catch(Exception e3) {
					e3.printStackTrace();
				}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBounds(195, 459, 112, 47);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("Close");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_2.setBounds(374, 459, 112, 47);
		contentPane.add(btnNewButton_2);
		
		
	}
}
